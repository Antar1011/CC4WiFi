mkdir ~/Desktop/CC
cd CC4Wifi
python CC4Wifi.py ~/Desktop/CC/
